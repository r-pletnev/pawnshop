//Global Vars
var version = "1.1";
var SchemeXML;

var gDoneButton;
var gInfoButton;

var currentFade;

var fadeOpacity = 50;
var fadeDirection = 1;
var fade = false;

function setup()
{
  //Set up defaults
  setOpacity('next', fadeOpacity);
  setOpacity('prev', fadeOpacity);
  if(window.widget)
  {
    if(widget.preferenceForKey("showHex"))
    {
      document.getElementById('hexValues').style.display = "block";
      document.getElementById('showHex').checked = true;
    }
  }
  
	gDoneButton = new AppleGlassButton(document.getElementById("doneButton"), "Done", hidePrefs);
  gInfoButton = new AppleInfoButton(document.getElementById("infoButton"), document.getElementById("front"), "white", "white", showPrefs);
	
	loadScheme('last');
}

function showPrefs()
{
  var front = document.getElementById("front");
  var back = document.getElementById("back");

  if(window.widget)
    widget.prepareForTransition("ToBack");

  front.style.display = "none";
  back.style.display = "block";

  if(window.widget)
    setTimeout('widget.performTransition();', 0);  
}

function hidePrefs()
{
  var front = document.getElementById("front");
  var back = document.getElementById("back");

  if(window.widget)
    widget.prepareForTransition("ToFront");

  back.style.display = "none";
  front.style.display = "block";
  
  if(window.widget)
    setTimeout('widget.performTransition();', 0);
  
  //Redraw palette to fix disappearing canvas bug
  alert('');
  drawPalette();
}


//Utility funcs
function labelClick(id)
{
	var chk = document.getElementById(id);
	chk.checked = !chk.checked;
	
	if(id == 'showHex')
    toggleHex();
}

function openURL(url)
{
  if(widget) widget.openURL(url);
}

function toggleHex()
{
  displayHex = document.getElementById('showHex').checked;

	if(window.widget)
	{
		if(displayHex)
		{
			widget.setPreferenceForKey(true, "showHex");
			document.getElementById('hexValues').style.display = "block";
		}
		else
		{
			widget.setPreferenceForKey(null, "showHex");
			document.getElementById('hexValues').style.display = "none";
		}
  }
}

function startFade(id)
{
  if(!fade)
  {
    fade = true;
    setTimeout("doFade('" + id + "')", 70);
  }
}

function stopFade()
{
  fade = false;
}

function doFade(id)
{
  if(fade)
  {
    if(fadeOpacity >= 100)
      fadeDirection = -1;
    else if(fadeOpacity <= 50)
      fadeDirection = 1;
  
    fadeOpacity += (5 * fadeDirection);
  
    setOpacity(id, fadeOpacity);
    setTimeout("doFade('" + id + "')", 70);
  }
  else
  {
    fadeOpacity = 50;
    setOpacity(id, fadeOpacity);
  }
}

function fadeElement(id, opacity, direction)
{
  if(opacity > 100)
    fadeElement(id, 100, -1);
  else if(opacity < 0)
  {
    setOpacity(id, 0);
    return;  
  }
  else if(opacity <= 100)
  {
    setOpacity(id, opacity);
    opacity += (5 * direction);
    currentFade = window.setTimeout("fadeElement('" + id + "'," + opacity + "," + direction + ")", opacity);
  }
}

function setOpacity(id, opacity)
{
  document.getElementById(id).style.opacity = opacity / 100;
}

function copyValue(value)
{
  widget.system("/bin/echo -n '" + value + "' | /usr/bin/pbcopy", null);
  
  //Fade copy message
  document.getElementById("message").innerHTML = '<span class="highlight">' + value + '</span> copied to the clipboard';
  
  window.clearTimeout(currentFade);
  fadeElement('message', 0, 1);
}

function rTrim(string)
{
	var regex = /((\s*\S+)*)\s*/;
	return string.replace(regex, "$1");
}


//Palette functions
function loadScheme(id)
{  
  var qs = "http://www.colorschemer.com/schemes/xml.php?id=" + id;
  
  xhr = new XMLHttpRequest();
  xhr.open("GET", qs, true);
  
  xhr.onreadystatechange = function()
  {
    if (xhr.readyState == 4 && xhr.status == 200)
    {
      if (xhr.responseText == 'ERROR')
      {
        alert("Error loading scheme!");
        return;
      }
      
      SchemeXML = xhr.responseXML.documentElement;
      
      //Set the title
      title = SchemeXML.getElementsByTagName('title')[0].firstChild.nodeValue;
      
      if(title.length > 24)
        title = rTrim(title.substr(0,24)) + "...";
      
      document.getElementById('title').innerHTML = '<span class="link" id="titleLink">' +  title + '</span>';
      
      document.getElementById('titleLink').onclick = function()
      {
        openURL('http://www.colorschemer.com/schemes/viewscheme.php?id=' + SchemeXML.getElementsByTagName('id')[0].firstChild.nodeValue);
      }
      
      //Draw the colors
      drawPalette();

      //Set the next/prev buttons
      if(SchemeXML.getElementsByTagName('prev')[0].firstChild)
      {
        document.getElementById('prev').style.display = "block";
        
        document.getElementById('prev').onclick = function()
        {
          loadScheme(SchemeXML.getElementsByTagName('prev')[0].firstChild.nodeValue);
        } 
      }
      else
      {
        if(fade) stopFade(); //prevent continuous fade when hidden
        document.getElementById('prev').style.display = "none";
      }
      
      if(SchemeXML.getElementsByTagName('next')[0].firstChild)
      {
        document.getElementById('next').style.display = "block";
        
        document.getElementById('next').onclick = function()
        {
          loadScheme(SchemeXML.getElementsByTagName('next')[0].firstChild.nodeValue);
        } 
      }
      else
      {
        if(fade) stopFade(); //prevent continuous fade when hidden
        document.getElementById('next').style.display = "none";
      }
    }
  }
  
  xhr.send(null);
}

function drawPalette()
{
  var palette = document.getElementById("palette");
  var context = palette.getContext("2d");
  var reflection =  document.getElementById("reflection");
  var refContext = reflection.getContext("2d"); 

  var i;
  var swatchSize = 33, spacing = 8;
  var tRGB, tHSV;
  var color, hex, RGB;
  
  var total_colors = SchemeXML.getElementsByTagName('count')[0].firstChild.nodeValue;
  var numDisplayColors = Math.min(6, total_colors);
  var paletteOffset = Math.round((palette.width - ((numDisplayColors * swatchSize) + ((numDisplayColors - 1) * spacing))) / 2);
  
  context.save();
  refContext.save();
  
  context.clearRect(0, 0, palette.width, palette.height);
  
  for(i = 0; i < numDisplayColors; i++)
  {
    color = SchemeXML.getElementsByTagName('color')[i];
    hex = color.getElementsByTagName('hex')[0].firstChild.nodeValue;
    RGB = HexToRGB(hex);

    //Draw the swatch
    context.setFillColor(RGB['r'] / 255, RGB['g'] / 255, RGB['b'] / 255, 1.0);
    context.fillRect(paletteOffset + i * (swatchSize + spacing), 1, swatchSize - 2, swatchSize - 2); //+1
    
    //Draw the shadow
    tHSV = RGBToHSV(RGB);
    tHSV['v'] -= 0.08;
    if(tHSV['v'] < 0) tHSV['v'] = 0;
    tRGB = HSVToRGB(tHSV);
    context.setStrokeColor(tRGB['r'] / 255, tRGB['g'] / 255, tRGB['b'] / 255, 1.0);
    context.strokeRect(paletteOffset + 1.5 + i * (swatchSize + spacing), 2.5, swatchSize - 4, swatchSize - 4); //+2.5
    
    tHSV['v'] -= 0.12;
    if(tHSV['v'] < 0) tHSV['v'] = 0.0;
    tRGB = HSVToRGB(tHSV);
    context.setStrokeColor(tRGB['r'] / 255, tRGB['g'] / 255, tRGB['b'] / 255, 1.0);
    context.strokeRect(paletteOffset + 0.5 + i * (swatchSize + spacing), 1.5, swatchSize - 2, swatchSize - 2); //+1.5
    
    //Update HEX caption
    document.getElementById('hex' + (i + 1)).style.display = 'inline-block';
    document.getElementById('hex' + (i + 1)).innerHTML = hex;
  }

  for(i = 6; i > numDisplayColors; i--)
    document.getElementById('hex' + i).style.display = 'none';

  //Draw reflection
  refContext.clearRect(0, 0, reflection.width, reflection.height);
  refContext.drawImage(palette, 0, 0/*, palette.width, palette.Height*/);

  var gradient = refContext.createLinearGradient(0, 0, 0, reflection.height);

  gradient.addColorStop(0.8, "rgba(255, 255, 255, 1.0)");
  gradient.addColorStop(0, "rgba(255, 255, 255, 0.75)");

  refContext.globalCompositeOperation = "destination-out";
  refContext.fillStyle = gradient;
  refContext.beginPath();
  refContext.rect(0, 0, reflection.width, reflection.height);
  refContext.closePath();
  refContext.fill();

  //Draw the white outlines
  for(i = 0; i < Math.min(6, total_colors); i++)
  {
    context.strokeStyle = "rgba(255, 255, 255, 1.0)";
    context.strokeRect(paletteOffset - 0.5 + i * (swatchSize + spacing), 0.5, swatchSize, swatchSize); //+0.5
  }
  
  refContext.restore();
  context.restore();
}


//Color conversion functions
function RGBToHex(RGB)
{
  var hex = DecToHex(RGB['r']) + DecToHex(RGB['g']) + DecToHex(RGB['b']);
  return hex.toUpperCase();
}
function DecToHex(v)
{
  v = (v > 255) ? 255 : (v < 0) ? 0 : v; 
  var vX = Math.floor(v / 16); 
  var vY = v % 16; 
  return  vX.toString(16) + vY.toString(16);
}

function HexToRGB(hex)
{
  var result = new Array();
  
  result['r'] = parseInt(hex.substr(0, 2), 16);
  result['g'] = parseInt(hex.substr(2, 2), 16);
  result['b'] = parseInt(hex.substr(4, 2), 16);
  return result;
}

function RGBToHSV(RGB)
{
  var HSV = new Array();
  
  r = RGB['r'] / 255;
  g = RGB['g'] / 255;
  b = RGB['b'] / 255;
  
  var min = Math.min(r, g, b);
  var max = Math.max(r, g, b);
  var d = max - min;
  
  HSV['v'] = max;
  
  if(d <= 0)
  {
    HSV['h'] = 0;
    HSV['s'] = 0;
  }
  else
  {
    HSV['s'] = d / max;

    var dR = (((max - r) / 6) + (d / 2)) / d;
    var dG = (((max - g) / 6) + (d / 2)) / d;
    var dB = (((max - b) / 6) + (d / 2)) / d;
 
    if(r == max)
      HSV['h'] = dB - dG;
    else if(g == max)
      HSV['h'] = (1 / 3) + dR - dB;
    else if(b == max)
      HSV['h'] = (2 / 3) + dG - dR;
 
    if(HSV['h'] < 0.0)
      HSV['h'] += 1.0;
    if(HSV['h'] > 1.0)
      HSV['h'] -= 1.0;
  }
      
  return HSV;
}

function HSVToRGB(HSV)
{
  var RGB = new Array();
  
  var h = HSV['h'];
  var s = HSV['s'];
  var v = HSV['v'];
  
  if(s <= 0)
  {
    var tV = Math.round(v * 255);
    RGB['r'] = tV;
    RGB['g'] = tV;
    RGB['b'] = tV;
  }
  else
  {
    h *= 6;
    if(h == 6)
      h = 0;
      
    var I = Math.floor(h);
    var J = h - I;
    var X = v * (1.0 - s);
    var Y = v * (1.0 - s * J);
    var Z = v * (1.0 - s * (1.0 - J));
  
    switch(I)
    {
      case 0:
        RGB['r'] = v;
        RGB['g'] = Z;
        RGB['b'] = X;
        break;
      
      case 1:
        RGB['r'] = Y;
        RGB['g'] = v;
        RGB['b'] = X;
        break;
        
      case 2:
        RGB['r'] = X;
        RGB['g'] = v;
        RGB['b'] = Z;
        break;
      
      case 3:
        RGB['r'] = X;
        RGB['g'] = Y;
        RGB['b'] = v;
        break;
      
      case 4:
        RGB['r'] = Z;
        RGB['g'] = X;
        RGB['b'] = v;
        break;
        
      default:
        RGB['r'] = v;
        RGB['g'] = X;
        RGB['b'] = Y;
        break;
    }
 
    RGB['r'] *= 255;
    RGB['g'] *= 255;
    RGB['b'] *= 255;
  }
  
  return RGB;
}
