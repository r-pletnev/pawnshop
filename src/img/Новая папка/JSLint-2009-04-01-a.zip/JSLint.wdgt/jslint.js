/*
JSLint Dashboard widget ©2009 Michael Newton
This work is distributed under the Mozilla Public License v1.1
Based on JSLint ©2002 Douglas Crockford - see fulljslint.js for JSLint licensing and copyright information
*/

/*jslint
	adsafe:false, bitwise:false, browser:false, cap:false, css:false, dashboard:true, debug:true, eqeqeq:true,
	evil:true, forin:false, fragment:false, immed:true, laxbreak:false, newcap:true, nomen:true, on:false, 
	onevar:true, passfail:false, plusplus:false, regexp:true, rhino:false, safe:false, sidebar:false, 
	strict:false, sub:false, undef:true, white:false, widget:false
*/
/*global JSLINT*/
var prefs = {
	all: ['adsafe', 'bitwise', 'browser', 'cap', 'css', 'dashboard', 'debug', 'eqeqeq', 'evil', 'forin', 
	'fragment', 'immed', 'indent', 'laxbreak', 'newcap', 'nomen', 'on', 'onevar', 'passfail', 'plusplus', 
	'predef', 'regexp', 'rhino', 'safe', 'sidebar', 'strict', 'sub', 'undef', 'white', 'widget'],
	recommended: ['eqeqeq', 'immed', 'newcap', 'nomen', 'undef', 'white'],
	goodparts: ['bitwise', 'eqeqeq', 'immed', 'newcap', 'nomen', 'onevar', 'plusplus', 'regexp', 'undef', 'white'],
	none: []
};


function pref_clear() {
	var els = document.getElementById('back').getElementsByTagName('input'),
		i, el;
	for (i = 0; (el = els[i]); i++) {
		if (el && el.type === 'checkbox') {
			el.checked = false;
		}
		else if (el && el.type === 'text') {
			el.value = '';
		}
	}
}

function goodparts_prefs() {
	var i, el;
	pref_clear();
	for (i = 0; i < prefs.goodparts.length; i++) {
		el = document.getElementsByName(prefs.goodparts[i]);
		if (el && el[0].type === 'checkbox') {
			el[0].checked = true;
		}
	}
}

function recommended_prefs() {
	var i, el;
	pref_clear();
	for (i = 0; i < prefs.recommended.length; i++) {
		el = document.getElementsByName(prefs.recommended[i]);
		if (el && el[0].type === 'checkbox') {
			el[0].checked = true;
		}
	}
}

//
// Function: load()
// Called by HTML body element's onload event when the widget is ready to start
//
function load() {
	var gauge = document.getElementById('error_gauge'),
		indicators = gauge.childNodes[0].childNodes,
		output = document.getElementById('output');
	indicators[0].title = 'No errors';
	indicators[1].title = 'Undefined globals';
	indicators[2].title = 'Code errors';
	indicators[3].title = 'Fatal error';
	output.contentEditable = true;
	output.addEventListener('click', function(e) {e.stopPropagation(); e.preventDefault();}, false);
}

//
// Function: remove()
// Called when the widget has been removed from the Dashboard
//
function remove() {
    // Stop any timers to prevent CPU usage
    // Remove any preferences as needed
	for (var i = 0, prefname; (prefname = prefs.all[i]); i++) {
		widget.setPreferenceForKey(null, prefname);
	}
}

//
// Function: hide()
// Called when the widget has been hidden
//
function hide() {
    // Stop any timers to prevent CPU usage
}

//
// Function: show()
// Called when the widget has been shown
//
function show() {
    // Restart any timers that were stopped on hide
}

//
// Function: sync()
// Called when the widget has been synchronized with .Mac
//
function sync() {
    // Retrieve any preference values that you need to be synchronized here
    // Use this for an instance key's value:
    // instancePreferenceValue = widget.preferenceForKey(null, createInstancePreferenceKey("your-key"));
    //
    // Or this for global key's value:
    // globalPreferenceValue = widget.preferenceForKey(null, "your-key");
}

//
// Function: showBack(event)
// Called when the info button is clicked to show the back of the widget
//
// event: onClick event from the info button
//
function showBack(event) {
    var front = document.getElementById("front"),
		back = document.getElementById("back"),
		el, prefval, prefname, i;

    if (window.widget) {
        widget.prepareForTransition("ToBack");
		for (i = 0; (prefname = prefs.all[i]); i++) {
			el = document.getElementsByName(prefname);
			if (el) {
				if (el[0].type === 'checkbox') {
					prefval = parseInt(widget.preferenceForKey(prefname), 10);
					el[0].checked = isNaN(prefval) ? false : true;
				}
				else if (el[0].type === 'text') {
					prefval = widget.preferenceForKey(prefname);
					el[0].value = prefval || '';
				}
			}
		}
    }

    front.style.display = "none";
    back.style.display = "block";

    if (window.widget) {
        setTimeout('widget.performTransition()', 0);
    }
}

//
// Function: showFront(event)
// Called when the done button is clicked from the back of the widget
//
// event: onClick event from the done button
//
function showFront(event) {
    var front = document.getElementById("front"),
		back = document.getElementById("back"),
		el, prefval, prefname, i;

    if (window.widget) {
        widget.prepareForTransition("ToFront");
		for (i = 0; (prefname = prefs.all[i]); i++) {
			el = document.getElementsByName(prefname);
			if (el) {
				switch (el[0].type) {
					case 'checkbox': prefval = el[0].checked ? '1' : null; break;
					case 'text': prefval = el[0].value; break;
					default: continue;
				}
				widget.setPreferenceForKey(prefval, prefname);
			}
		}
    }

    front.style.display="block";
    back.style.display="none";

    if (window.widget) {
        setTimeout('widget.performTransition()', 0);
    }
}

if (window.widget) {
    widget.onremove = remove;
    widget.onhide = hide;
    widget.onshow = show;
    widget.onsync = sync;
}

function jslint(e) {
	var input = document.getElementById('input'),
		output = document.getElementById('output'),
		error_gauge = document.getElementById('error_gauge'),
		options = {}, 
		err_level = 0,
		i, opt, err, status, report;
	for (i = 0; i < prefs.all.length; i++) {
		opt = widget.preferenceForKey(prefs.all[i]);
		if (opt) {
			options[prefs.all[i]] = (prefs.all[i] === 'predef') ? opt.split(/\s*,\s*/) : opt;
		}
	}
	status = JSLINT(input.value, options);
	report = JSLINT.report(true);
	if (status === true) {
		if (!report) {
//no errors
			err_level = 1;
			report = 'No errors!';
		}
		else {
//implied globals
			err_level = 2;
		}
	}
	else {
		err = JSLINT.errors;
		if (err[err.length - 1] === null) {
//fatal error
			err_level = 4;
		}
		else {
//errors
			err_level = 3;
		}
	}
	output.innerHTML = report;
	error_gauge.object.setValue(err_level);
}
